# x += wartosc równoważne x = x + wartość

x = 100
print('Na początku', x)

while x > 0:
    x -= 30
    print('W pętli', x)

print('KONIEC')
