a = 3
b = 9
h = 6.5

# Można policzyć wewnątrz printa - ale to zły styl programowania
print((a + b) * h / 2)
