cena = float(input('Cena za kg: '))
ilosc = float(input(f'Waga : '))

naleznosc = cena * ilosc
print(f'Należność: {naleznosc}')
