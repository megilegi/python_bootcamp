a = 3
b = 9
h = 6.5

# Lepiej wynik obliczenia zapisać na dodatkowej zmiennej - to zwiększy czytelność kodu
pole_trapezu = (a + b) * h / 2
print(pole_trapezu)
