# Pętla nieskończona (naprawdę)
while True:
    print('Pętla działa')

print('KONIEC') # nigdy się nie wypisze
