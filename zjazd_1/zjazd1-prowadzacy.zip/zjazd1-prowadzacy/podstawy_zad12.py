i = 1

while i <= 100:
    print(f'{i} ^ 2 = {i*i}')
    i += 1

print('Koniec')
