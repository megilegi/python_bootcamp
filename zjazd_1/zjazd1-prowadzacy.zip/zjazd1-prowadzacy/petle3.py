x = 0

# Pętla nieskończona (naprawdę)
while True:
    x += 1
    print(f'x = {x}')

